/*
 * Public API Surface of ng2-simple-timer
 */

export * from './lib/ng2-simple-timer.service';
